#!/bin/bash
fecha=$(date +%c)

echo "$fecha" >> milogev2.log
